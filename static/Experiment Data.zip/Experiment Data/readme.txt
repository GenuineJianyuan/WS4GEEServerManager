The experimental data is used to test the WS4GEE client system as described in the Tutorial for WS4GEEClient.docx
(1) WuhanBoundary is used to test (1) GEE-enabled dynamic data services generation
(2) buffer.py , FVC.py are used to test (2) GEE-enabled geoprocessing services generation
(3) GetCoverage Request.xml is the templates described in the table in (3) Service invocation